<?php
namespace Daw2\BaseDeDatos;
use PDO;
use PDOException;
class DBConection {

    private $dsn;
    private $user;
    private $password;
    private $db;
    private $db_name;
    protected static $connection;
    public static $instance;

    public function __construct() {
        $config = json_decode(file_get_contents('../config.json'), TRUE);
        $this->dsn = "{$config['DBType']}:dbname={$config['DBName']};host={$config['Host']}";;
        $this->user = "{$config['User']}";
        $this->db = "{$config['DBType']}:host={$config['Host']}";
        $this->password = "{$config['Password']}";
        $this->db_name =  "{$config['DBName']}";
        DBConection::$connection = DBConection::dbConnect();
    } 

    private function dbConnect() {
        try {
            $connection = new PDO($this->dsn, $this->user, $this->password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
            $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $connection;
        } catch (PDOException $error) {
            if($error->getCode() === 1049 ) { // Database no existe 
                echo "<h2>No existe la base de datos, creándola</h2>";
                $connection = new PDO($this->db, $this->user, $this->password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
                $query = $connection->prepare("CREATE DATABASE IF NOT EXISTS $this->db_name COLLATE utf8_spanish_ci");
                $query->execute();

                if($query){
                    $use_db = $connection->prepare("USE $this->db_name");
                    $use_db->execute();
                }

                if($use_db){
                    $DBFile = file_get_contents("./baseDatos.sql");
                    $connection->exec($DBFile);
                }
            }
        
            return $connection;

        }
    }

    function dbClose() {
        $this->connection = null;
    }

    public static function getConnection() { //Esta función permite que la conexión se haga solo 1 vez
        if(!isset(self::$instance)){
            $object = __CLASS__;
            self::$instance = new $object;
            //echo "Primera vez";
        }
        //echo "Siguientes veces";
        return self::$instance;
    }

}

?>