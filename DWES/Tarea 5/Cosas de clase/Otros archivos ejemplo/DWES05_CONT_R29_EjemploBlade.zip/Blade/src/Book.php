<?php
namespace Daw2\BaseDeDatos;
use Daw2\BaseDeDatos\DBConection;
use PDO;

class Book extends DBConection{

    private $id;
    private $isbn;
    private $title;
    private $author;
    private $stock;
    private $price;

    public function __construct($isbn, $title, $author, $stock, $price){
        $this->isbn = $isbn;
        $this->title = $title;
        $this->author = $author;
        $this->stock = $stock;
        $this->price = $price;
        parent::getConnection();
    }

    public function insert(){
        $stmt = parent::$connection->prepare("INSERT INTO book ( isbn, title, author, stock, price) VALUES (:isbn, :title, :author, :stock, :price)");
        
        $stmt->bindValue(':isbn', $this->isbn);
        $stmt->bindValue(':title', $this->title);
        $stmt->bindValue(':author', $this->author);
        $stmt->bindValue(':stock', $this->stock);
        $stmt->bindValue(':price', $this->price);

        $stmt->execute();
    }

    public static function delete($id){
        $stmt = parent::$connection->prepare("DELETE FROM book WHERE id = :id");

        $stmt->bindValue(':id', $id);

        $stmt->execute();
    }

    public function update($id){
        $stmt = parent::$connection->prepare("UPDATE book SET isbn = :isbn, title = :title, author = :author, stock = :stock, price = :price WHERE id = :id");

        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':isbn', $this->isbn);
        $stmt->bindValue(':title', $this->title);
        $stmt->bindValue(':author', $this->author);
        $stmt->bindValue(':stock', $this->stock);
        $stmt->bindValue(':price', $this->price);
        
        $stmt->execute();
    }

    public static function getBook($id){
        $stmt = DBConection::$connection->prepare("SELECT * FROM book WHERE id = $id");
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function getBooks(){
        $stmt = DBConection::$connection->prepare("SELECT * FROM book");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function showAllBooks(){
        $stmt = DBConection::$connection->prepare("SELECT * FROM book");
        $stmt->execute();
        echo<<<EOT
            <form method='post' action='$_SERVER[PHP_SELF]'>
            <table class="table">
                <tr>
                    <th colspan = '8' style = 'text-align: center;font-size: 3rem;'>BOOKS</th>
                </tr>
                <tr>
                    <th>Detalles</th>
                    <th>ID</th>
                    <th>ISBN</th>
                    <th>TITLE</th>
                    <th>AUTHOR</th>
                    <th>STOCK</th>
                    <th>PRICE</th>
                </tr>
                <tr>
        EOT;
        while($resultado = $stmt->fetch(PDO::FETCH_ASSOC)){
            echo "<td><button type='submit' name='detalles' value='" . $resultado['id'] . "' class='detalles'>DETALLES</button></td>";
            foreach($resultado as $key => $value){
                echo "<td>" . $value . "</td>";
            }
            echo "<td>
            <button type='submit' name='eliminar' value='" . $resultado['id'] . "' class='eliminar'>ELIMINAR</button>
            <button type='submit' name='actualizar' value='" . $resultado['id'] . "' class='actualizar'>ACTUALIZAR</button>
            </td>
            </tr>";
        }
        echo "</table></form>";
        
        return $resultado;
    }

    public static function getBookForBuy(){
        $stmt = parent::$connection->prepare("SELECT id, isbn, title, author, stock, price FROM book");
        $stmt->execute();
        
        echo<<<EOT
            <form method='post' action='$_SERVER[PHP_SELF]' class='compra'>
            
            <table class="table">
                <tr>
                    <th colspan = '8' style = 'text-align: center;font-size: 3rem;'>BOOKS FOR BUY</th>
                </tr>
                <tr>
                    <th>ID</th>
                    <th>ISBN</th>
                    <th>TITLE</th>
                    <th>AUTHOR</th>
                    <th>STOCK</th>
                    <th>PRICE</th>
                    <th>SELECCION</th>
                    <th>CANTIDAD</th>
                </tr>
                <tr>
        EOT;
        while($resultado = $stmt->fetch(PDO::FETCH_ASSOC)){
            foreach($resultado as $key => $value){
                echo "<td>" . $value . "</td>";
            }
            echo "<td>
            <input type='checkbox' name='buyBook[]' value='$resultado[id]'>
            </td>
            <td><input type='number' name='$resultado[id]' min='0' max='$resultado[stock]'></td>
            </tr>";
        }
        echo "<input type='hidden' name='customer_id' value='$_GET[id]'>
        <div>
        <button type='submit' name='buy' value='buy' class='actualizar'>COMPRAR</button>
        <button type='submit' name='volver' value='volver' class='eliminar'>Volver</button>
        </div>
        </table>
        </form>";

        return $resultado;
    }
}

?>