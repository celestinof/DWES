<?php
    namespace Daw2\BaseDeDatos;
    use Daw2\BaseDeDatos\DBConection;
    use PDO;

    class Customer extends DBConection{

        private $id;
        private $firstname;
        private $surname;
        private $email;
        private $type;

        public function __construct($firstname, $surname, $email, $type){
            $this->firstname = $firstname;
            $this->surname = $surname;
            $this->email = $email;
            $this->type = $type;
            parent::getConnection();
        }

        public static function getCustomer($id){
            $stmt = DBConection::$connection->prepare("SELECT * FROM customer WHERE id = $id");
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }

        public static function showAllCustomers(){
            $stmt = DBConection::$connection->prepare("SELECT id,firstname, surname, email, type FROM customer ORDER BY type DESC, firstname");
            $stmt->execute();
            
            echo<<<EOT
            <form method='post' action='$_SERVER[PHP_SELF]' class='compra' >
            <button type='submit' name='volver' value='volver' class='eliminar'>Volver</button>
            <table class="table">
                <tr>
                    <th colspan = '6' style = 'text-align: center;font-size: 3rem;'>CUSTOMERS</th>
                </tr>
                <tr>
                    <th>ID</th>
                    <th>FIRSTNAME</th>
                    <th>SURNAME</th>
                    <th>EMAIL</th>
                    <th>TYPE</th>
                </tr>
                <tr>
            EOT;
            while($res = $stmt->fetch(PDO::FETCH_ASSOC)){
                echo "<tr>";
                foreach($res as $key => $value){
                    echo "<td>$value</td>";
                }
                echo "<td><button type='submit' name='customer_id' value='$res[id]' class='actualizar'>COMPRAR LIBROS</button>
                <button type='submit' name='viewBook' value='$res[id]' class='actualizar'>VER LIBROS</button></td>
                </tr>";    
            }
            echo "</table>
            </form>";

        }
        
        public static function buyBook($customer_id, $book_id, $amount){
            $stmt = DBConection::$connection->prepare("INSERT INTO sale (customer_id, date) VALUES (:customer_id, :fecha)");
            $fecha = date("Y-m-d H:i:s");

            $stmt->bindValue(":customer_id", $customer_id);
            $stmt->bindValue(":fecha", $fecha);

            $stmt->execute();

            $stmt = DBConection::$connection->prepare("SELECT LAST_INSERT_ID()");
            $stmt->execute();

            $sale_id = $stmt->fetch(PDO::FETCH_ASSOC);

            $stmt = DBConection::$connection->prepare("INSERT INTO sale_book (book_id, sale_id, amount) VALUES (:book_id, :sale_id, :amount)");

            $stmt->bindValue(":book_id", $book_id);
            $stmt->bindValue(":sale_id", $sale_id['LAST_INSERT_ID()']);
            $stmt->bindValue(":amount", $amount);

            $stmt->execute();

            $stmt = DBConection::$connection->prepare("UPDATE book SET stock = stock - $amount WHERE id = $book_id");

            $stmt->execute();
        }

        public static function viewBuyBooks($customer_id){
            $stmt = DBConection::$connection->prepare("SELECT id FROM sale WHERE customer_id = :customer_id");

            $stmt->bindValue(":customer_id", $customer_id);
            $stmt->execute();

            $stmt_bis = DBConection::$connection->prepare("SELECT title, amount FROM book, sale_book WHERE sale_id = :sale AND id = book_id");


            echo "<table class='table'>
            <tr>
                <th>TÍTULO</th>
                <th>CANTIDAD QUE TIENE</th>
            </tr>
            ";
            while($res = $stmt->fetch(PDO::FETCH_ASSOC)){
                foreach($res as $sale_id){
                    $stmt_bis->bindValue(":sale", $sale_id);
                    $stmt_bis->execute();
                    while($resultado = $stmt_bis->fetch(PDO::FETCH_ASSOC)){
                        echo "<tr>
                            <td>$resultado[title]</td>
                            <td>$resultado[amount]</td>
                        </tr>";
                    }
                }
            }
            echo "</table>";
        }
    }
?>