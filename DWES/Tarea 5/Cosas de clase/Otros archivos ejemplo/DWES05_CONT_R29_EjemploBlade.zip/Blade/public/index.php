<?php
require '../vendor/autoload.php';
use Windwalker\Edge\Loader\EdgeFileLoader;
use Windwalker\Edge\Edge;
use Daw2\BaseDeDatos\Book;
use Daw2\BaseDeDatos\DBConection;

DBConection::getConnection();

$titulo = "Título";
$encabezado = "LIBROS";

$books = Book::getBooks();

$blade = new Edge(new EdgeFileLoader(array('../views/plantillas', '../views')));
echo $blade->render('vistaLibros', array('titulo'=>$titulo, 'encabezado'=> $encabezado, 'books'=>$books));
?>