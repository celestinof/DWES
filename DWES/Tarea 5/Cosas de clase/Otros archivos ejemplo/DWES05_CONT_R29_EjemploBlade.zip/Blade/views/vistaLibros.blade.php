@extends('vista')
@section('titulo')
    {{$titulo}}
@endsection
@section ('encabezado')
    {{$encabezado}}
@endsection
@section ('contenido')
<table class="table table-striped">
    <tr class="text-center">
        <th scope="col">ID</th>
        <th scope="col">ISBN</th>
        <th scope="col">TITULO</th>
        <th scope="col">AUTOR</th>
        <th scope="col">STOCK</th>
        <th scope="col">PRICE</th>
    </tr>
@foreach ($books as $book)
    <tr class="text-center">
    @foreach ($book as $key=>$value)
        <td class="text-centr">{{$value}}</td>
    @endforeach
    </tr>
@endforeach

</table>
@endsection